<h1 align="center">
Best Discord Music Bot </h1><br/>

## **Installation | How to use the Bot**

**1.** Install [node.js v16](https://nodejs.org/en/) or higher

**2.** Download this repo and unzip it | or git clone it

**3.** Fill in everything in **`config.json`**

**4.** after Fill everything in config run **`setup.bat`**

**5.** start the bot with **`start.bat`**
<br/>

### _Modify - config.json_

```javascript
{
    "token": "Bot_Token",
}
```

<br/>

If Any Bug Open Pull Request
